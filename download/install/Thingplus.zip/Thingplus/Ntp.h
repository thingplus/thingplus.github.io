#ifndef NTP_H
#define NTP_H

void NtpBegin(void);
void NtpSync(void);

#endif
